import glob
import os
import pandas as pd

os.listdir(os.getcwd()) 
filelist = glob.glob('*.csv') 

dfs= []    

for file in filelist:
    df = pd.read_csv(file)
    df.columns = df.columns.str.replace('[?,!,&,$,%]','')
    df.columns = df.columns.str.replace(' ','')
    df.columns = df.columns.str.lower() 
    df = df.dropna(how='all')
    dfs.append(df)

master_df = pd.concat(dfs, ignore_index=True) 

master_df.to_csv('MasterCSV.CSV', index = False)


